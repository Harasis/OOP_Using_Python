from setuptools import setup

setup(name='Gaussian_binomial_distributions',
      version='0.1',
      description='Gaussian distributions',
      packages=['distributions'],
      zip_safe=False)
